<template>
  <section>
    <h1>About</h1>
    <p>This is a sample about page.</p>
  </section>
</template>

<script setup lang="ts"></script>

<style scoped>
section {
  padding: 16px;
}
</style>

<template>
  <section>
    <h1>Home</h1>
    <p>Welcome to the home view.</p>
  </section>
</template>

<script setup lang="ts"></script>

<style scoped>
section {
  padding: 16px;
}
</style>
